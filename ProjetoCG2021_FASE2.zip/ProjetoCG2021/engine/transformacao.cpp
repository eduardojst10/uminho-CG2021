//
// Created by eduardo on 28/03/21.
//

#include "transformacao.h"
#include <cmath>
#include <math.h>
#include <iostream>


/**
 * Inicia uma matriz ID
 * @return
 */

TRANSFORMACAO init_transformacao(){
    TRANSFORMACAO  t = (TRANSFORMACAO) malloc(sizeof (struct transformacao));
    for(int l=0;l<4;l++){
        for(int c=0;c<4;c++){
            if(l==c) t->matriz[l][c] = 1; //matriz identidade

            else t->matriz[l][c] = 0;
        }
    }
    return t;
}

/**
 * Criar Matriz de escala
 * @param x
 * @param y
 * @param z
 * @return
 */
TRANSFORMACAO scale(float x, float y, float z){
    TRANSFORMACAO t =init_transformacao();
    t->matriz[0][0] = t->matriz[0][0]*x;
    t->matriz[1][1] = t->matriz[1][1]*y;
    t->matriz[2][2] = t->matriz[2][2]*z;
    return t;
}
/**
 * Criar matriz de translação
 * @param x
 * @param y
 * @param z
 * @return
 */
TRANSFORMACAO translate(float x,float y,float z){
    TRANSFORMACAO  t = init_transformacao();
    t->matriz[0][3]=x;
    t->matriz[1][3]=y;
    t->matriz[2][3]=z;
    return t;
}

/**
 * Criar Matriz de rotacao no eixo do X
 * @param x
 * @param y
 * @param z
 * @param angle
 * @return
 */
TRANSFORMACAO rotateX(float x, float y,float z,float angle){
    TRANSFORMACAO t = init_transformacao();
    float radiano = angle * M_PI/180.f;
    t->matriz[0][0]= 1;
    t->matriz[0][1]= 0;
    t->matriz[0][2]= 0;

    t->matriz[1][0]=0;
    t->matriz[1][1]=cos(radiano);
    t->matriz[1][2]=-sin(radiano);

    t->matriz[2][0]=0;
    t->matriz[2][1]=sin(radiano);
    t->matriz[2][2]=cos(radiano);
    return t;
}

/**
 * Criar Matriz de rotacao no eixo do Y
 * @param x
 * @param y
 * @param z
 * @param angle
 * @return
 */

TRANSFORMACAO  rotateY(float x,float y, float z,float  angle){
    TRANSFORMACAO t = init_transformacao();
    float radiano = angle * M_PI/180.f;
    t->matriz[0][0]= cos(radiano);
    t->matriz[0][1]= 0;
    t->matriz[0][2]= sin(radiano);

    t->matriz[1][0]=0;
    t->matriz[1][1]=1;
    t->matriz[1][2]=0;

    t->matriz[2][0]=-sin(radiano);
    t->matriz[2][1]=0;
    t->matriz[2][2]=cos(radiano);
    return t;
}

/**
 * Criar Matriz de rotacao no eixo do Z
 * @param x
 * @param y
 * @param z
 * @param angle
 * @return
 */

TRANSFORMACAO rotateZ(float x,float y, float z,float  angle){
    TRANSFORMACAO t = init_transformacao();
    float radiano = angle * M_PI/180.f;
    t->matriz[0][0]= cos(radiano);
    t->matriz[0][1]= -sin(radiano);
    t->matriz[0][2]= 0;

    t->matriz[1][0]=sin(radiano);
    t->matriz[1][1]=cos(radiano);
    t->matriz[1][2]=0;

    t->matriz[2][0]=0;
    t->matriz[2][1]=0;
    t->matriz[2][2]=1;
    return t;
}


TRANSFORMACAO escolheRotate(float x,float y, float z,float  angle) {
    if (x == 1) return rotateX(x, y, z, angle);
    if (y == 1) return rotateY(x, y, z, angle);
    if (z == 1) return rotateZ(x, y, z, angle);

    else {
        std::cout << "ERRO"<< "\n";
        return NULL;

    }
}
