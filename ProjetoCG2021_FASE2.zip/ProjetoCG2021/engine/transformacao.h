//
// Created by eduardo on 28/03/21.
//

#ifndef GENERATOR_TRANSFORMACAO_H
#define GENERATOR_TRANSFORMACAO_H

struct transformacao {
        float matriz[4][4];
};

typedef struct transformacao * TRANSFORMACAO;


TRANSFORMACAO init_transformacao();
TRANSFORMACAO scale(float x, float y, float z);
TRANSFORMACAO translate(float x,float y,float z);
TRANSFORMACAO rotateX(float x, float y,float z,float angle);
TRANSFORMACAO rotateY(float x, float y,float z,float angle);
TRANSFORMACAO rotateZ(float x, float y,float z,float angle);
TRANSFORMACAO escolheRotate(float x,float y, float z,float  angle);

#endif //GENERATOR_TRANSFORMACAO_H
