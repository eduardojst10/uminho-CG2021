//
// Created by eduardo on 11/03/21.
//
#include <vector>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <iosfwd>
#ifndef GENERATOR_SPHERE_H
#define GENERATOR_SPHERE_H

#include <string>
#include <math.h>

void sphere(std::string file, float radius, int slices, int stacks);

#endif
