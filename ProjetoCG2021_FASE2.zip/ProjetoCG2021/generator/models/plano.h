//
// Created by eduardo on 07/03/21.
//
#include <iostream>
#include <fstream>
#include <iosfwd>
#include <vector>
#ifndef PROJETOCG2021_PLANO_H
#define PROJETOCG2021_PLANO_H

void write_plano(std::string ficheiro, float x, float y, float z);
void geraPlano(char* path, float x);


#endif //PROJETOCG2021_PLANO_H
