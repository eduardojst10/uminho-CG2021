//
// Created by eduardo on 11/03/21.
//

#include <vector>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <iosfwd>
#ifndef GENERATOR_CONE_H
#define GENERATOR_CONE_H


void cone(std::string file, float radius, float height, int slices, int stacks);

#endif
